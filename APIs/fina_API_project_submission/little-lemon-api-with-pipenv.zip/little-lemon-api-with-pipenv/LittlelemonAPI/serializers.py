# Note 1: "serializers" is the process of converting Django
# data models and databases to meaningful APIs on a web browsers
# to a readable format like JSON and XML.
