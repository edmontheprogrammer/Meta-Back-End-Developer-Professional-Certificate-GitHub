for i in range(n):
#     a.append(int(input()))
#     if (i < n // 2):
#         ededorta = ((sum(a)/len(a)))
#     else:
#         hendesiorta = hendesiorta*a[i]/n
# print("Ededi orta", ededorta, end="\n")
# print("Hendesi orta", hendesiorta, end="\n")

# # Your trying to divide the list data structure, "a", by the integer "2". Python is saying that's
# # not allowed.
# # Note 1: Python is not Java. You should remove the semi-colon ";" at the end of your codes.
# # TypeError: unsupported operand type(s) for /: 'list' and 'int'
